# Clase 23

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Creacion_biblioteca_lista.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=kKuvJEsxDGo&index=23&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

A partir del ejercicio anterior, crear la biblioteca �People� que pueda manejar una lista de �Personas� (agregar a
   la lista personas)

- Version: 0.1 del 06 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*  Array de punteros a estructuras creadas en forma din�mica
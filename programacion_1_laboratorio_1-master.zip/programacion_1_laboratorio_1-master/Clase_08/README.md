# Clase 8

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Estructuras.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=fe3iL_tlQK8&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV&index=8

### Ejercicio
#### Objetivo:

   Realizar una agenda para guardar los datos de hasta 200 personas
   de las cuales se toman los siguientes datos:
       Nombre
       Apellido
       legajo (NO SE PUEDE REPETIR)
   Usar una estructura para representar a la persona.

   a- Realizar un programa con un men� de opciones para hacer altas ,
      bajas y modificaciones (ABM) de una agenda.
   b- Mostrar un listado ordenado por Apellido

- Version: 0.1 del 01 enero de 2016
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   Manipulaci�n y chequeo de cadena de caracteres
*   arrays paraleos
*   bajas logicas
# Clase 9

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Estructuras.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=8h6R46Xrr9I&index=9&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

El juego de cartas del siete y medio. Consiste en ir pidiendo
   cartas intentando sumar 7.5 puntos sin pasarse. Gana el jugador
   que m�s se acerca a 7.5. Se utiliza una baraja espa�ola. Sota,
   caballo y rey valen medio punto. Las dem�s cartas punt�an seg�n
   su valor num�rico (de 1 a 7). Utilizar la biblioteca utn.h.

- Version: 0.1 del 29 diciembre de 2015
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   Utilizaci�n de arrays y estructuras